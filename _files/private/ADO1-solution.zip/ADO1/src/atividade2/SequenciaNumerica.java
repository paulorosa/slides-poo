package atividade2;

public class SequenciaNumerica {
	protected int valorAtual;
    public SequenciaNumerica (int valorAtual) {
        this.valorAtual = valorAtual;
    }
    public int valorAtual() {
        return valorAtual;
    }
}
