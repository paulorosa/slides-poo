package atividade1;
public class Fatorial {
	private int valorAtual;
	private int posicao;

    public Fatorial () {
        this.valorAtual = 1;
        this.posicao = 0;
    }

    public void proximoValor () {
    	posicao = posicao +1;
        valorAtual = valorAtual * posicao;
    }

    public int valorAtual() {
		return valorAtual;
	}

    public static void main (String[] args) {
        int quantidade = Integer.parseInt(args[0]);

        Fatorial fatorial =  new Fatorial();

        for (int i=0; i<quantidade; i++) {
            System.out.print (fatorial.valorAtual() + " ");
            fatorial.proximoValor();
        }
    }        
}